from pathlib import Path
import pandas as pd
import numpy as np
import hashlib
from collections import defaultdict

# ---------------------------------------------------------
# Paths
# ---------------------------------------------------------
BASE = Path(__file__).resolve().parents[1]

DATA_DIR = BASE / "data" / "notices"
LABEL_FILE = BASE / "output" / "q2a_labelled_similarity.csv"
OUTPUT_DIR = BASE / "output"
EVIDENCE_DIR = BASE / "evidence"

OUTPUT_DIR.mkdir(exist_ok=True)
EVIDENCE_DIR.mkdir(exist_ok=True)

# ---------------------------------------------------------
# LSH parameters
# ---------------------------------------------------------
K = 512
BANDS = 128
ROWS = 4
SEED = 20240917

# Heavy bucket threshold
CAP = 500

# ---------------------------------------------------------
# Hash parameters
# ---------------------------------------------------------
rng = np.random.default_rng(SEED)

A = rng.integers(
    1,
    np.iinfo(np.uint64).max,
    size=K,
    dtype=np.uint64
)

B = rng.integers(
    0,
    np.iinfo(np.uint64).max,
    size=K,
    dtype=np.uint64
)


# ---------------------------------------------------------
# Text normalization
# ---------------------------------------------------------
def normalize_text(text):

    if pd.isna(text):
        return ""

    text = str(text).lower()

    text = "".join(
        ch if ch.isalpha() or ch.isspace() else " "
        for ch in text
    )

    return " ".join(text.split())


# ---------------------------------------------------------
# 5-word shingles
# ---------------------------------------------------------
def create_shingles(text, n=5):

    words = text.split()

    if len(words) < n:
        return set()

    return {
        " ".join(words[i:i+n])
        for i in range(len(words) - n + 1)
    }


# ---------------------------------------------------------
# Deterministic hash
# ---------------------------------------------------------
def hash_shingle(shingle):

    digest = hashlib.blake2b(
        shingle.encode("utf-8"),
        digest_size=8
    ).digest()

    return int.from_bytes(
        digest,
        "little"
    )


# ---------------------------------------------------------
# MinHash
# ---------------------------------------------------------
def minhash_signature(shingles):

    signature = np.full(
        K,
        np.iinfo(np.uint64).max,
        dtype=np.uint64
    )

    for shingle in shingles:

        h = np.uint64(
            hash_shingle(shingle)
        )

        values = A * h + B

        signature = np.minimum(
            signature,
            values
        )

    return signature


# ---------------------------------------------------------
# Create LSH bucket keys
# ---------------------------------------------------------
def get_bucket_keys(signature):

    keys = []

    for band in range(BANDS):

        start = band * ROWS
        end = start + ROWS

        band_values = signature[start:end]

        bucket_hash = int.from_bytes(
            hashlib.blake2b(
                band_values.tobytes(),
                digest_size=8
            ).digest(),
            "big",
            signed=False
        )

        if bucket_hash >= 2**63:
            bucket_hash -= 2**64

        keys.append(
            (band, bucket_hash)
        )

    return keys


# ---------------------------------------------------------
# Load notices
# ---------------------------------------------------------
files = sorted(
    DATA_DIR.glob("*.csv")
)

frames = []

for file in files:
    frames.append(
        pd.read_csv(file)
    )

notices = pd.concat(
    frames,
    ignore_index=True
)

print("Total notices:", len(notices))


# ---------------------------------------------------------
# Build bucket membership
# ---------------------------------------------------------
buckets = defaultdict(list)

print()
print("Building LSH buckets...")

for count, row in enumerate(
    notices.itertuples(index=False),
    start=1
):

    row_dict = row._asdict()

    notice_id = str(
        row_dict["notice_id"]
    )

    title = normalize_text(
        row_dict["title"]
    )

    body = normalize_text(
        row_dict["body"]
    )

    text = title + " " + body

    shingles = create_shingles(
        text,
        5
    )

    signature = minhash_signature(
        shingles
    )

    keys = get_bucket_keys(
        signature
    )

    for key in keys:
        buckets[key].append(notice_id)

    if count % 1000 == 0:
        print(
            f"Processed {count} / {len(notices)}"
        )


print()
print(
    "Total distinct buckets:",
    len(buckets)
)


# ---------------------------------------------------------
# Bucket statistics
# ---------------------------------------------------------
bucket_sizes = {
    key: len(value)
    for key, value in buckets.items()
}

total_pairs_before = sum(
    size * (size - 1) // 2
    for size in bucket_sizes.values()
)

heavy_buckets = {
    key: size
    for key, size in bucket_sizes.items()
    if size > CAP
}

pairs_removed = sum(
    size * (size - 1) // 2
    for size in heavy_buckets.values()
)

total_pairs_after = (
    total_pairs_before - pairs_removed
)

print()
print("Heavy bucket threshold:", CAP)
print(
    "Heavy buckets:",
    len(heavy_buckets)
)

print(
    "Candidate pairs before:",
    total_pairs_before
)

print(
    "Candidate pairs removed:",
    pairs_removed
)

print(
    "Candidate pairs after:",
    total_pairs_after
)

print(
    "Percentage workload removed:",
    round(
        100 * pairs_removed / total_pairs_before,
        2
    )
)


# ---------------------------------------------------------
# Load labelled pairs
# ---------------------------------------------------------
labels = pd.read_csv(
    LABEL_FILE
)

print()
print(
    "Labelled pairs:",
    len(labels)
)

print(
    "Label columns:",
    list(labels.columns)
)


# ---------------------------------------------------------
# Identify pair columns
# ---------------------------------------------------------
id_columns = [
    c for c in labels.columns
    if c.lower() in [
        "notice_a",
        "notice_b",
        "id_a",
        "id_b",
        "notice_id_a",
        "notice_id_b"
    ]
]

if len(id_columns) < 2:

    raise ValueError(
        "Could not identify the two notice ID columns."
    )

id_a = id_columns[0]
id_b = id_columns[1]

print(
    "Pair columns:",
    id_a,
    id_b
)


# ---------------------------------------------------------
# Build bucket lookup for notices
# ---------------------------------------------------------
notice_to_buckets = defaultdict(list)

for key, members in buckets.items():

    for notice_id in members:

        notice_to_buckets[
            notice_id
        ].append(key)


# ---------------------------------------------------------
# Candidate test
# ---------------------------------------------------------
def is_candidate(
    notice_a,
    notice_b,
    ignore_heavy=False
):

    buckets_a = notice_to_buckets.get(
        str(notice_a),
        []
    )

    buckets_b = set(
        notice_to_buckets.get(
            str(notice_b),
            []
        )
    )

    for key in buckets_a:

        if ignore_heavy and key in heavy_buckets:
            continue

        if key in buckets_b:
            return True

    return False


# ---------------------------------------------------------
# Evaluate labelled pairs
# ---------------------------------------------------------
before_results = []
after_results = []

for _, row in labels.iterrows():

    a = row[id_a]
    b = row[id_b]

    before = is_candidate(
        a,
        b,
        ignore_heavy=False
    )

    after = is_candidate(
        a,
        b,
        ignore_heavy=True
    )

    before_results.append(before)
    after_results.append(after)


labels["candidate_before"] = before_results
labels["candidate_after"] = after_results


# ---------------------------------------------------------
# Quality metrics
# ---------------------------------------------------------
same_mask = (
    labels["label"].astype(str).str.lower()
    == "same"
)

different_mask = (
    labels["label"].astype(str).str.lower()
    == "different"
)

same_recall_before = (
    labels.loc[
        same_mask,
        "candidate_before"
    ].mean() * 100
)

same_recall_after = (
    labels.loc[
        same_mask,
        "candidate_after"
    ].mean() * 100
)

different_survival_before = (
    labels.loc[
        different_mask,
        "candidate_before"
    ].mean() * 100
)

different_survival_after = (
    labels.loc[
        different_mask,
        "candidate_after"
    ].mean() * 100
)


print()
print("Retrieval quality")
print("-----------------")

print(
    f"SAME recall before: "
    f"{same_recall_before:.2f}%"
)

print(
    f"SAME recall after:  "
    f"{same_recall_after:.2f}%"
)

print(
    f"DIFFERENT survival before: "
    f"{different_survival_before:.2f}%"
)

print(
    f"DIFFERENT survival after:  "
    f"{different_survival_after:.2f}%"
)


# ---------------------------------------------------------
# Save labelled evaluation
# ---------------------------------------------------------
evaluation_file = (
    OUTPUT_DIR /
    "q2e_mitigation_labelled_results.csv"
)

labels.to_csv(
    evaluation_file,
    index=False
)

print()
print(
    "Saved:",
    evaluation_file
)


# ---------------------------------------------------------
# Save summary
# ---------------------------------------------------------
summary = pd.DataFrame([{
    "bucket_cap": CAP,
    "heavy_buckets": len(heavy_buckets),
    "candidate_pairs_before": total_pairs_before,
    "candidate_pairs_removed": pairs_removed,
    "candidate_pairs_after": total_pairs_after,
    "workload_reduction_percent":
        100 * pairs_removed / total_pairs_before,
    "same_recall_before":
        same_recall_before,
    "same_recall_after":
        same_recall_after,
    "different_survival_before":
        different_survival_before,
    "different_survival_after":
        different_survival_after
}])

summary_file = (
    OUTPUT_DIR /
    "q2e_mitigation_summary.csv"
)

summary.to_csv(
    summary_file,
    index=False
)

print(
    "Saved:",
    summary_file
)

print()
print(
    "Q2(e) mitigation experiment completed."
)