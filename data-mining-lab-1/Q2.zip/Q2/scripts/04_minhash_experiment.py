import numpy as np
import pandas as pd
import re
import glob
import hashlib
import time
from pathlib import Path


# ==========================================
# Q2(b) - MinHash Accuracy Experiment
# ==========================================

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data"
OUTPUT = BASE / "output"

OUTPUT.mkdir(exist_ok=True)

NOTICE_DIR = DATA / "notices"


# ------------------------------------------
# Load Q2(a) results
# ------------------------------------------

pairs = pd.read_csv(
    OUTPUT / "q2a_labelled_similarity.csv"
)

print("=" * 70)
print("Q2(b) - MINHASH ACCURACY EXPERIMENT")
print("=" * 70)

print("Labelled pairs:", len(pairs))


# ------------------------------------------
# Accuracy requirement
# ------------------------------------------

epsilon = 0.05
z = 1.96

required_k = int(
    np.ceil((z ** 2 * 0.25) / (epsilon ** 2))
)

K = 512

print("\nAccuracy requirement:")
print("Absolute error :", epsilon)
print("Confidence     : 0.95")
print("Required hashes:", required_k)
print("Selected hashes:", K)


# ------------------------------------------
# Load notices
# ------------------------------------------

files = sorted(
    glob.glob(str(NOTICE_DIR / "*.csv"))
)

notices = pd.concat(
    [pd.read_csv(f) for f in files],
    ignore_index=True
)

print("\nNotice files:", len(files))
print("Total notices:", len(notices))


# ------------------------------------------
# Text cleaning
# ------------------------------------------

def clean_text(title, body):

    text = str(title) + " " + str(body)

    text = text.lower()

    text = re.sub(
        r"[^a-z]+",
        " ",
        text
    )

    return re.sub(
        r"\s+",
        " ",
        text
    ).strip()


def make_shingles(text, n=5):

    words = text.split()

    return {
        " ".join(words[i:i+n])
        for i in range(len(words) - n + 1)
    }


# ------------------------------------------
# Create shingles
# ------------------------------------------

print("\nCreating 5-word shingles...")

shingles = {}

for _, row in notices.iterrows():

    text = clean_text(
        row["title"],
        row["body"]
    )

    shingles[row["notice_id"]] = make_shingles(
        text,
        5
    )

print("Shingles created.")


# ------------------------------------------
# Generate deterministic 64-bit hashes
# ------------------------------------------

def shingle_hash(shingle):

    return int.from_bytes(
        hashlib.blake2b(
            shingle.encode(),
            digest_size=8
        ).digest(),
        "big"
    )


print("\nHashing unique shingles...")

unique_shingles = set()

for notice_id in shingles:

    unique_shingles.update(
        shingles[notice_id]
    )

print(
    "Unique shingles:",
    len(unique_shingles)
)

hash_values = {
    s: shingle_hash(s)
    for s in unique_shingles
}


# ------------------------------------------
# Generate MinHash signature
#
# Instead of hashing every shingle 512 times,
# use deterministic transformations of the
# base 64-bit hash.
# ------------------------------------------

MASK = (1 << 64) - 1

rng = np.random.default_rng(20240917)

A = rng.integers(
    1,
    MASK,
    size=K,
    dtype=np.uint64
)

B = rng.integers(
    0,
    MASK,
    size=K,
    dtype=np.uint64
)


def minhash_signature(shingle_set):

    signature = np.full(
        K,
        np.uint64(MASK)
    )

    for shingle in shingle_set:

        h = np.uint64(
            hash_values[shingle]
        )

        values = (
            A * h + B
        )

        signature = np.minimum(
            signature,
            values
        )

    return signature


# ------------------------------------------
# Only labelled notices are needed for
# accuracy experiment
# ------------------------------------------

notice_ids = set(
    pairs["notice_id_a"]
).union(
    pairs["notice_id_b"]
)

print(
    "\nLabelled notices requiring signatures:",
    len(notice_ids)
)


# ------------------------------------------
# Generate signatures
# ------------------------------------------

start = time.perf_counter()

signatures = {}

for i, notice_id in enumerate(
    notice_ids,
    start=1
):

    signatures[notice_id] = minhash_signature(
        shingles[notice_id]
    )

    if i % 200 == 0:
        print(
            "Signatures generated:",
            i
        )

signature_time = (
    time.perf_counter() - start
)

print(
    "\nSignature generation time:",
    round(signature_time, 3),
    "seconds"
)


# ------------------------------------------
# Compare exact Jaccard with MinHash
# ------------------------------------------

exact_scores = []
estimated_scores = []
errors = []

start = time.perf_counter()

for _, row in pairs.iterrows():

    a = row["notice_id_a"]
    b = row["notice_id_b"]

    exact = float(
        row["jaccard_5gram"]
    )

    estimated = float(
        np.mean(
            signatures[a] == signatures[b]
        )
    )

    exact_scores.append(exact)
    estimated_scores.append(estimated)
    errors.append(
        abs(exact - estimated)
    )

pair_time = (
    time.perf_counter() - start
)

pairs["minhash_512"] = estimated_scores
pairs["absolute_error"] = errors


# ------------------------------------------
# Error statistics
# ------------------------------------------

errors = pairs["absolute_error"]

print("\n" + "=" * 70)
print("REALISED MINHASH ERROR")
print("=" * 70)

print(
    "Mean absolute error:",
    round(errors.mean(), 5)
)

print(
    "Median absolute error:",
    round(errors.median(), 5)
)

print(
    "Maximum absolute error:",
    round(errors.max(), 5)
)

print(
    "95th percentile error:",
    round(errors.quantile(0.95), 5)
)

print(
    "Pairs within ±0.05:",
    round(
        (errors <= 0.05).mean() * 100,
        2
    ),
    "%"
)

print(
    "Pairs outside ±0.05:",
    round(
        (errors > 0.05).mean() * 100,
        2
    ),
    "%"
)

print(
    "Pair comparison time:",
    round(pair_time, 4),
    "seconds"
)


# ------------------------------------------
# Error by label
# ------------------------------------------

print("\nError by label:")

for label in ["same", "different"]:

    subset = pairs[
        pairs["label"] == label
    ]["absolute_error"]

    print(
        "\n",
        label.upper()
    )

    print(
        "Mean error:",
        round(subset.mean(), 5)
    )

    print(
        "Maximum error:",
        round(subset.max(), 5)
    )

    print(
        "Within ±0.05:",
        round(
            (subset <= 0.05).mean() * 100,
            2
        ),
        "%"
    )


# ------------------------------------------
# Save results
# ------------------------------------------

output_file = (
    OUTPUT / "q2b_minhash_results.csv"
)

pairs.to_csv(
    output_file,
    index=False
)

print(
    "\nResults saved to:",
    output_file
)

print("\nQ2(b) experiment complete.")