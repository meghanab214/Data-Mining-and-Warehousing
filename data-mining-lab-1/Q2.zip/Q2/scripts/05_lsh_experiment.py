from pathlib import Path
import pandas as pd
import numpy as np
import hashlib
import matplotlib.pyplot as plt

# ---------------------------------------------------------
# Paths
# ---------------------------------------------------------
BASE = Path(__file__).resolve().parents[1]

OUTPUT = BASE / "output"
EVIDENCE = BASE / "evidence"

OUTPUT.mkdir(exist_ok=True)
EVIDENCE.mkdir(exist_ok=True)

INPUT_FILE = OUTPUT / "q2a_labelled_similarity.csv"

# ---------------------------------------------------------
# Load labelled similarity data
# ---------------------------------------------------------
df = pd.read_csv(INPUT_FILE)

print("Labelled pairs:", len(df))

# ---------------------------------------------------------
# LSH configurations
# Total hashes = bands × rows = 512
# ---------------------------------------------------------
CONFIGS = [
    (32, 16),
    (64, 8),
    (128, 4),
    (256, 2)
]

# ---------------------------------------------------------
# LSH candidate probability
# P(candidate) = 1 - (1 - s^r)^b
# ---------------------------------------------------------
def candidate_probability(similarity, bands, rows):
    return 1 - (1 - similarity ** rows) ** bands


# ---------------------------------------------------------
# Evaluate configurations
# ---------------------------------------------------------
results = []

for bands, rows in CONFIGS:

    probabilities = candidate_probability(
        df["jaccard_5gram"].values,
        bands,
        rows
    )

    # Treat probability as candidate retrieval estimate
    candidate = probabilities >= 0.5

    same_mask = df["label"] == "same"
    different_mask = df["label"] == "different"

    same_recall = candidate[same_mask].mean() * 100
    different_survival = candidate[different_mask].mean() * 100
    overall_candidate_rate = candidate.mean() * 100

    results.append({
        "bands": bands,
        "rows": rows,
        "same_recall_percent": same_recall,
        "different_survival_percent": different_survival,
        "overall_candidate_rate_percent": overall_candidate_rate
    })

    print()
    print(f"{bands} bands x {rows} rows")
    print(f"  SAME recall: {same_recall:.2f}%")
    print(f"  DIFFERENT survival: {different_survival:.2f}%")
    print(f"  Overall candidate rate: {overall_candidate_rate:.2f}%")


# ---------------------------------------------------------
# Save configuration results
# ---------------------------------------------------------
result_df = pd.DataFrame(results)

output_file = OUTPUT / "q2c_lsh_configurations.csv"
result_df.to_csv(output_file, index=False)

print()
print("Saved:", output_file)


# ---------------------------------------------------------
# Selected operating configuration
# ---------------------------------------------------------
BANDS = 128
ROWS = 4

print()
print("Selected operating configuration:")
print(f"{BANDS} bands x {ROWS} rows")


# ---------------------------------------------------------
# Candidate survival curve
# ---------------------------------------------------------
similarities = np.linspace(0, 1, 1001)

probability = candidate_probability(
    similarities,
    BANDS,
    ROWS
)

# Operating similarity point for the graph
OPERATING_SIMILARITY = 0.60

operating_probability = candidate_probability(
    OPERATING_SIMILARITY,
    BANDS,
    ROWS
)

print()
print(
    f"At similarity {OPERATING_SIMILARITY:.2f}, "
    f"candidate probability = {operating_probability:.4f} "
    f"({operating_probability * 100:.2f}%)"
)


# ---------------------------------------------------------
# Plot
# ---------------------------------------------------------
plt.figure(figsize=(8, 5))

plt.plot(
    similarities,
    probability,
    label=f"{BANDS} bands × {ROWS} rows"
)

plt.axvline(
    OPERATING_SIMILARITY,
    linestyle="--",
    label=f"Operating similarity = {OPERATING_SIMILARITY:.2f}"
)

plt.axhline(
    operating_probability,
    linestyle=":"
)

plt.scatter(
    [OPERATING_SIMILARITY],
    [operating_probability]
)

plt.xlabel("True 5-word Jaccard similarity")
plt.ylabel("Probability of becoming an LSH candidate")
plt.title("LSH Candidate Survival Curve")

plt.ylim(0, 1.05)
plt.xlim(0, 1)

plt.grid(True, alpha=0.3)
plt.legend()

plt.tight_layout()

graph_file = EVIDENCE / "C1_lsh_candidate_curve.png"

plt.savefig(graph_file, dpi=200)
plt.close()

print()
print("Saved graph:", graph_file)
print()
print("Q2(c) LSH experiment completed.")