from pathlib import Path
import pandas as pd
import numpy as np
import hashlib
import psycopg2
import csv
from io import StringIO

# ---------------------------------------------------------
# Paths
# ---------------------------------------------------------
BASE = Path(__file__).resolve().parents[1]

DATA_DIR = BASE / "data" / "notices"

# ---------------------------------------------------------
# LSH parameters
# ---------------------------------------------------------
K = 512
BANDS = 128
ROWS = 4
SEED = 20240917

# ---------------------------------------------------------
# PostgreSQL connection
# ---------------------------------------------------------
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "annapurna",
    "user": "annapurna",
    "password": "annapurna"
}

# ---------------------------------------------------------
# Text normalization
# ---------------------------------------------------------
def normalize_text(text):

    if pd.isna(text):
        return ""

    text = str(text).lower()

    text = "".join(
        ch if ch.isalpha() or ch.isspace() else " "
        for ch in text
    )

    return " ".join(text.split())


# ---------------------------------------------------------
# Create 5-word shingles
# ---------------------------------------------------------
def create_shingles(text, n=5):

    words = text.split()

    if len(words) < n:
        return set()

    return {
        " ".join(words[i:i+n])
        for i in range(len(words) - n + 1)
    }


# ---------------------------------------------------------
# Deterministic 64-bit hash
# ---------------------------------------------------------
def hash_shingle(shingle):

    digest = hashlib.blake2b(
        shingle.encode("utf-8"),
        digest_size=8
    ).digest()

    return int.from_bytes(
        digest,
        "little"
    )


# ---------------------------------------------------------
# Generate MinHash parameters
# ---------------------------------------------------------
rng = np.random.default_rng(SEED)

A = rng.integers(
    1,
    np.iinfo(np.uint64).max,
    size=K,
    dtype=np.uint64
)

B = rng.integers(
    0,
    np.iinfo(np.uint64).max,
    size=K,
    dtype=np.uint64
)


# ---------------------------------------------------------
# Generate MinHash signature
# ---------------------------------------------------------
def minhash_signature(shingles):

    signature = np.full(
        K,
        np.iinfo(np.uint64).max,
        dtype=np.uint64
    )

    for shingle in shingles:

        h = np.uint64(
            hash_shingle(shingle)
        )

        values = A * h + B

        signature = np.minimum(
            signature,
            values
        )

    return signature


# ---------------------------------------------------------
# Load all notice CSV files
# ---------------------------------------------------------
files = sorted(
    DATA_DIR.glob("*.csv")
)

if not files:
    raise FileNotFoundError(
        f"No CSV files found in {DATA_DIR}"
    )

frames = []

for file in files:

    df = pd.read_csv(
        file
    )

    frames.append(df)


notices = pd.concat(
    frames,
    ignore_index=True
)

print(
    "Total notices:",
    len(notices)
)

print(
    "Notice files:",
    len(files)
)


# ---------------------------------------------------------
# Required columns
# ---------------------------------------------------------
notice_id_col = "notice_id"
portal_col = "portal_id"
title_col = "title"
body_col = "body"


required_columns = [
    notice_id_col,
    portal_col,
    title_col,
    body_col
]

for column in required_columns:

    if column not in notices.columns:

        raise ValueError(
            f"Required column not found: {column}"
        )


print()
print("Columns:")
print(list(notices.columns))

print()
print("Notice ID column:", notice_id_col)
print("Portal column:", portal_col)
print("Title column:", title_col)
print("Body column:", body_col)


# ---------------------------------------------------------
# Generate LSH bucket rows
# ---------------------------------------------------------
bucket_rows = []

print()
print(
    "Generating MinHash signatures and LSH buckets..."
)


for count, row in enumerate(
    notices.itertuples(index=False),
    start=1
):

    row_dict = row._asdict()

    notice_id = str(
        row_dict[notice_id_col]
    )

    title = normalize_text(
        row_dict[title_col]
    )

    body = normalize_text(
        row_dict[body_col]
    )

    text = title + " " + body

    shingles = create_shingles(
        text,
        5
    )

    signature = minhash_signature(
        shingles
    )


    # -----------------------------------------------------
    # Divide 512 hashes into 128 bands × 4 rows
    # -----------------------------------------------------
    for band in range(BANDS):

        start = band * ROWS
        end = start + ROWS

        band_values = signature[
            start:end
        ]

        band_bytes = band_values.tobytes()

        bucket_hash = int.from_bytes(
            hashlib.blake2b(
                band_bytes,
                digest_size=8
            ).digest(),
            "big",
            signed=False
        )

        # PostgreSQL BIGINT is signed
        if bucket_hash >= 2**63:

            bucket_hash -= 2**64


        bucket_rows.append(
            (
                band,
                bucket_hash,
                notice_id
            )
        )


    if count % 1000 == 0:

        print(
            f"Processed {count} / {len(notices)} notices"
        )


print()
print(
    "Total bucket rows:",
    len(bucket_rows)
)


# ---------------------------------------------------------
# Connect to PostgreSQL
# ---------------------------------------------------------
print()
print(
    "Connecting to PostgreSQL..."
)

conn = psycopg2.connect(
    **DB_CONFIG
)

cur = conn.cursor()


# ---------------------------------------------------------
# Clear previous incomplete data
# ---------------------------------------------------------
print(
    "Clearing previous data..."
)

cur.execute(
    """
    TRUNCATE TABLE
        lsh_buckets,
        notices
    CASCADE
    """
)

conn.commit()


# ---------------------------------------------------------
# BULK LOAD NOTICES
# ---------------------------------------------------------
print(
    "Bulk loading notices..."
)

notice_buffer = StringIO()

notice_writer = csv.writer(
    notice_buffer,
    delimiter="\t",
    quotechar='"',
    quoting=csv.QUOTE_MINIMAL,
    lineterminator="\n"
)


for row in notices.itertuples(
    index=False
):

    row_dict = row._asdict()

    notice_id = str(
        row_dict[notice_id_col]
    )

    portal = str(
        row_dict[portal_col]
    )

    title = str(
        row_dict[title_col]
    )

    body = str(
        row_dict[body_col]
    )

    notice_writer.writerow([
        notice_id,
        portal,
        title,
        body
    ])


notice_buffer.seek(0)


cur.copy_expert(
    """
    COPY notices
    (
        notice_id,
        portal_id,
        title,
        body
    )
    FROM STDIN
    WITH (
        FORMAT CSV,
        DELIMITER E'\\t',
        QUOTE '"',
        ESCAPE '"'
    )
    """,
    notice_buffer
)

conn.commit()

print(
    "Notices loaded:",
    len(notices)
)


# ---------------------------------------------------------
# BULK LOAD LSH BUCKETS
# ---------------------------------------------------------
print()
print(
    "Bulk loading LSH buckets..."
)

bucket_buffer = StringIO()

bucket_writer = csv.writer(
    bucket_buffer,
    delimiter="\t",
    quotechar='"',
    quoting=csv.QUOTE_MINIMAL,
    lineterminator="\n"
)


for band, bucket_hash, notice_id in bucket_rows:

    bucket_writer.writerow([
        band,
        bucket_hash,
        notice_id
    ])


bucket_buffer.seek(0)


cur.copy_expert(
    """
    COPY lsh_buckets
    (
        band_no,
        bucket_hash,
        notice_id
    )
    FROM STDIN
    WITH (
        FORMAT CSV,
        DELIMITER E'\\t',
        QUOTE '"',
        ESCAPE '"'
    )
    """,
    bucket_buffer
)

conn.commit()

print(
    "LSH buckets loaded:",
    len(bucket_rows)
)


# ---------------------------------------------------------
# Update PostgreSQL statistics
# ---------------------------------------------------------
print()
print(
    "Updating PostgreSQL statistics..."
)

cur.execute(
    "ANALYZE notices"
)

cur.execute(
    "ANALYZE lsh_buckets"
)

conn.commit()


# ---------------------------------------------------------
# Verify final counts
# ---------------------------------------------------------
cur.execute(
    "SELECT COUNT(*) FROM notices"
)

notice_count = cur.fetchone()[0]


cur.execute(
    "SELECT COUNT(*) FROM lsh_buckets"
)

bucket_count = cur.fetchone()[0]


print()
print(
    "Final PostgreSQL counts"
)

print(
    "-----------------------"
)

print(
    "Notices:",
    notice_count
)

print(
    "LSH bucket rows:",
    bucket_count
)


# ---------------------------------------------------------
# Close connection
# ---------------------------------------------------------
cur.close()
conn.close()


print()
print(
    "Q2(d) full LSH index build completed."
)