import psycopg2
import time

DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "annapurna",
    "user": "annapurna",
    "password": "annapurna"
}

CAP = 500

conn = psycopg2.connect(**DB_CONFIG)
cur = conn.cursor()

print("Q2(e) Runtime Comparison")
print("=" * 50)

# BEFORE mitigation
print("\nBEFORE MITIGATION")
print("Counting candidate pairs from all buckets...")

start = time.perf_counter()

cur.execute("""
    SELECT COALESCE(
        SUM(bucket_size * (bucket_size - 1) / 2),
        0
    )
    FROM (
        SELECT band_no, bucket_hash, COUNT(*) AS bucket_size
        FROM lsh_buckets
        GROUP BY band_no, bucket_hash
    ) b;
""")

before_pairs = cur.fetchone()[0]
before_time = time.perf_counter() - start

print("Candidate pairs:", before_pairs)
print("Runtime: %.4f seconds" % before_time)


# AFTER mitigation
print("\nAFTER MITIGATION")
print("Ignoring buckets larger than", CAP, "notices...")

start = time.perf_counter()

cur.execute("""
    SELECT COALESCE(
        SUM(bucket_size * (bucket_size - 1) / 2),
        0
    )
    FROM (
        SELECT band_no, bucket_hash, COUNT(*) AS bucket_size
        FROM lsh_buckets
        GROUP BY band_no, bucket_hash
        HAVING COUNT(*) <= %s
    ) b;
""", (CAP,))

after_pairs = cur.fetchone()[0]
after_time = time.perf_counter() - start

print("Candidate pairs:", after_pairs)
print("Runtime: %.4f seconds" % after_time)


# Comparison
workload_reduction = (
    (before_pairs - after_pairs) / before_pairs * 100
)

runtime_reduction = (
    (before_time - after_time) / before_time * 100
)

print("\n" + "=" * 50)
print("RUNTIME COMPARISON")
print("=" * 50)

print("Before candidate pairs :", before_pairs)
print("After candidate pairs  :", after_pairs)

print("Workload reduction     : %.2f%%" % workload_reduction)

print("Before runtime         : %.4f seconds" % before_time)
print("After runtime          : %.4f seconds" % after_time)

print("Runtime change         : %.2f%%" % runtime_reduction)

print("\nQ2(e) runtime comparison completed.")

cur.close()
conn.close()