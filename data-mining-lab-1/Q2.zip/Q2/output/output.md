Q2(a) — Similarity definition and representation

A tender notice is represented using normalized words extracted from its title and body. The text is converted to lowercase, punctuation and numeric information such as reference numbers, dates and monetary formatting are removed, and whitespace is normalized. Portal-specific boilerplate is treated as noise because it is repeated across notices from the same portal without describing the underlying procurement opportunity.

The normalized text is decomposed into contiguous 5-word shingles. For two notices \(A\) and \(B\), similarity is measured using Jaccard similarity:

$$ J(A,B)=\frac{|S_A\cap S_B|}{|S_A\cup S_B|} $$

where \(S_A\) and \(S_B\) are the sets of 5-word shingles from the two notices.

I compared 3-word and 5-word shingles using the 900 manually labelled pairs. The labelled set contains 279 same pairs (31%) and 621 different pairs (69%), so it is not balanced.

With a similarity threshold of 0.50, 3-word shingles classified 72.76% of same pairs as similar but also classified 25.44% of different pairs as similar. 5-word shingles classified 72.40% of same pairs as similar while only 3.06% of different pairs exceeded the threshold. The median similarity of same pairs was 0.6642 for 5-word shingles compared with 0.6549 for 3-word shingles, while the median for different pairs dropped from 0.3876 to 0.2822.

Therefore, I adopted 5-word shingles, because they preserve nearly the same similarity for genuine duplicate notices while greatly reducing accidental similarity between different notices. This choice prioritizes reducing false merges, which have a substantially higher business cost than displaying an additional duplicate card.


The labelled examples demonstrate that similarity scores overlap for individual pairs. For example, the labelled same pair N010018/N010020 scores 0.2709 using 3-word shingles and 0.2553 using 5-word shingles, while the labelled different pair N007876/N008565 scores 0.2974 and 0.2097 respectively. Therefore, the representation is not treated as a perfect classifier; the larger labelled-pair distribution is used to evaluate the separation.


TASK-B  Reduced representation and MinHash size

The full 5-word-shingle representation is too large to retain for every notice during retrieval, so I use a MinHash signature as the reduced representation. The required estimation accuracy was set to ±0.05 absolute Jaccard error at 95% confidence.

For \(k\) independent MinHash functions, the variance of the Jaccard estimator is:

$$ Var(\hat J)=\frac{J(1-J)}{k} $$

The maximum variance occurs at \(J=0.5\), giving:

$$ 1.96\sqrt{\frac{0.25}{k}}\leq0.05 $$

Therefore:

$$ k\geq385 $$

I selected 512 hash functions as the reduced signature size because it is above the calculated minimum and provides a convenient fixed representation for the subsequent LSH stage.

Actual measured result

Your experiment produced:

Measure	Result
Labelled pairs	900
Labelled notices	1,644
Unique 5-word shingles	99,038
MinHash functions	512
Signature generation time	4.607 s
Mean absolute error	0.04068
Median absolute error	0.03473
Maximum absolute error	0.18454
95th-percentile error	0.10714
Within ±0.05	69.33%
Outside ±0.05	30.67%
Where it did not behave as expected

The mean absolute error of 0.04068 is below the required 0.05 tolerance, but the realised errors are not uniformly within ±0.05. Only 69.33% of labelled pairs were within the target error, while 30.67% exceeded it. The maximum observed error was 0.18454 and the 95th-percentile error was 0.10714. Error was higher among labelled same pairs (mean 0.06894) than different pairs (mean 0.02799). Thus, the 512-hash estimator is adequate in aggregate but does not guarantee ±0.05 accuracy for every individual pair.


TASK-(c)

Q2(c) results
LSH configuration	SAME recall	DIFFERENT survival	Overall candidates
32 × 16	35.84%	0.00%	11.11%
64 × 8	66.67%	0.81%	21.22%
128 × 4	93.91%	53.46%	66.00%
256 × 2	100.00%	100.00%	100.00%

LSH candidate retrieval: The 512-value MinHash signature was divided into different band/row configurations and evaluated on the 900 labelled pairs. The 32×16 configuration retained only 35.84% of same pairs, while 64×8 retained 66.67%. The 128×4 configuration retained 93.91% of same pairs, at the cost of 53.46% survival among different pairs. The 256×2 configuration retained all pairs and therefore provided almost no reduction. Hence, 128 bands × 4 rows was selected as the operating configuration because it provides high candidate recall while still reducing the search space compared with exhaustive all-pairs comparison. The LSH stage is treated only as candidate generation; the final merge decision will use a stricter similarity/rule-based criterion because a false merge is substantially more costly than a missed merge.


TASK-D
Relational home and access method: The LSH retrieval structure was stored in PostgreSQL in the lsh_buckets relation with (band_no, bucket_hash, notice_id). A composite B-tree primary-key index on (band_no, bucket_hash, notice_id) provides the retrieval path. For the tested bucket (band_no=99, bucket_hash=-7044433592672878987), PostgreSQL selected an Index Only Scan, returning 1,788 notice IDs in 2.952 ms, with zero heap fetches.

As an alternative, a sequential scan was tested by disabling index and bitmap scans. PostgreSQL used a Parallel Seq Scan with two workers. It returned the same 1,788 rows but examined the full relation, removing 511,404 rows per worker by the filter, and required 18.715 ms. Therefore, the indexed path substantially reduces the work required for bucket retrieval. The sequential scan was rejected as the routine retrieval method because LSH queries repeatedly filter by (band_no, bucket_hash).


TASK-E
Heavy-bucket analysis and mitigation: Across the 12,000-notice corpus, there were 553,968 distinct LSH buckets with an average size of 2.77 and a maximum size of 1,788. Although most buckets were small, 985 buckets contained more than 100 notices, 77 contained more than 500, and 13 contained more than 1,000. The full LSH structure generated 51,771,791 candidate pairs. Buckets larger than 500 alone generated 26,561,757 pairs, or 51.31% of the total candidate-pair workload.

To control this heavy tail, buckets with more than 500 notices were excluded from candidate expansion. This reduced candidate pairs from 51,771,791 to 25,210,034, a 51.31% workload reduction. On the 900 manually labelled pairs, SAME-pair recall decreased from 84.23% to 83.51%, a reduction of 0.72 percentage points, while DIFFERENT-pair survival decreased from 47.18% to 37.68%. Thus the mitigation substantially reduces candidate workload with a relatively small measured loss in duplicate-pair retrieval recall.