DROP TABLE IF EXISTS opportunity_alias;
DROP TABLE IF EXISTS notice_opportunity;
DROP TABLE IF EXISTS opportunities;

CREATE TABLE opportunities (
    opportunity_id BIGSERIAL PRIMARY KEY,
    card_id TEXT UNIQUE NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE notice_opportunity (
    notice_id TEXT PRIMARY KEY,
    opportunity_id BIGINT NOT NULL,
    first_assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    FOREIGN KEY (notice_id)
        REFERENCES notices(notice_id),

    FOREIGN KEY (opportunity_id)
        REFERENCES opportunities(opportunity_id)
);

CREATE TABLE opportunity_alias (
    old_opportunity_id BIGINT PRIMARY KEY,
    new_opportunity_id BIGINT NOT NULL,
    merged_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    FOREIGN KEY (old_opportunity_id)
        REFERENCES opportunities(opportunity_id),

    FOREIGN KEY (new_opportunity_id)
        REFERENCES opportunities(opportunity_id)
);

CREATE INDEX idx_notice_opportunity_opportunity
ON notice_opportunity(opportunity_id);