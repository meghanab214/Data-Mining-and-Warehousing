-- Q2(d): Relational storage for LSH buckets

DROP TABLE IF EXISTS lsh_buckets;
DROP TABLE IF EXISTS notices;

-- Basic notice table
CREATE TABLE notices (
    notice_id TEXT PRIMARY KEY,
    portal_id TEXT,
    title TEXT,
    body TEXT
);

-- LSH retrieval structure
CREATE TABLE lsh_buckets (
    band_no SMALLINT NOT NULL,
    bucket_hash BIGINT NOT NULL,
    notice_id TEXT NOT NULL,
    PRIMARY KEY (band_no, bucket_hash, notice_id),
    FOREIGN KEY (notice_id) REFERENCES notices(notice_id)
);

-- Access path for LSH bucket lookup
CREATE INDEX idx_lsh_bucket_btree
ON lsh_buckets (band_no, bucket_hash);