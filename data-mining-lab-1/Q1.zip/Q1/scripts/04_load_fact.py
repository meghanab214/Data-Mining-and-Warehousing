import io
import duckdb
import psycopg2


# -----------------------------
# PostgreSQL connection
# -----------------------------

pg = psycopg2.connect(
    host="localhost",
    port=5432,
    database="annapurna",
    user="annapurna",
    password="annapurna"
)

cur = pg.cursor()


# -----------------------------
# DuckDB connection
# -----------------------------

duck = duckdb.connect()

duck.execute("INSTALL httpfs")
duck.execute("LOAD httpfs")

duck.execute("""
CREATE OR REPLACE SECRET minio (
    TYPE S3,
    KEY_ID 'minioadmin',
    SECRET 'minioadmin',
    REGION 'us-east-1',
    ENDPOINT 'localhost:9000',
    USE_SSL false,
    URL_STYLE 'path'
);
""")


# -----------------------------
# Read curated Parquet data
# -----------------------------

print("Reading sales data from MinIO...")

sales = duck.execute("""
SELECT
    store_id,
    business_date,
    bill_no,
    line_no,
    product_code,
    quantity,
    unit_price,
    UPPER(line_type) AS line_type
FROM read_parquet(
    's3://annapoorna-sales/sales/year=*/month=*/store=*/*.parquet',
    hive_partitioning=true
)
""").fetchdf()

print(f"Sales rows read: {len(sales):,}")


# -----------------------------
# Normalize business date
# -----------------------------

sales["business_date"] = sales["business_date"].apply(
    lambda x: x.date() if hasattr(x, "date") else x
)


# -----------------------------
# Load store dimension
# -----------------------------

cur.execute("""
SELECT
    store_key,
    store_id
FROM dim_store
ORDER BY store_id
""")

store_map = {
    str(store_id).strip(): int(store_key)
    for store_key, store_id in cur.fetchall()
}

print("Store IDs in PostgreSQL:")
print(sorted(store_map.keys()))


# -----------------------------
# Load product dimension
# -----------------------------

cur.execute("""
SELECT
    product_key,
    product_code,
    valid_from,
    valid_to
FROM dim_product
""")

products = cur.fetchall()

product_map = {}

for product_key, product_code, valid_from, valid_to in products:

    code = str(product_code).strip()

    product_map.setdefault(code, []).append(
        (
            int(product_key),
            valid_from,
            valid_to
        )
    )


# -----------------------------
# Find correct product version
# -----------------------------

def find_product_key(product_code, business_date):

    code = str(product_code).strip()

    candidates = product_map.get(code, [])

    for product_key, valid_from, valid_to in candidates:

        if valid_from <= business_date <= valid_to:
            return product_key

    return None


# -----------------------------
# Prepare fact rows
# -----------------------------

print("Preparing fact rows...")

fact_rows = []

unmatched_stores = set()
unmatched_products = set()

for row in sales.itertuples(index=False):

    store_id = str(row.store_id).strip()

    if store_id not in store_map:
        unmatched_stores.add(store_id)
        continue

    store_key = store_map[store_id]

    product_code = str(row.product_code).strip()

    product_key = find_product_key(
        product_code,
        row.business_date
    )

    if product_key is None:
        unmatched_products.add(
            (
                product_code,
                str(row.business_date)
            )
        )

    # Calculate line amount
    amount = (
        float(row.quantity)
        * float(row.unit_price)
    )

    line_type = str(
        row.line_type
    ).strip().upper()


    # -------------------------
    # Revenue rules
    # -------------------------

    if line_type in (
        "SALE",
        "RETURN",
        "DISCOUNT",
        "VOID"
    ):

        # The source data already contains
        # the correct sign.
        revenue = amount

    else:

        # TAX and TENDER are not revenue.
        revenue = 0.0


    # -------------------------
    # Add fact row
    # -------------------------

    fact_rows.append(
        (
            str(row.bill_no).strip(),
            str(row.line_no).strip(),
            row.business_date,
            store_key,
            product_key,
            row.quantity,
            row.unit_price,
            line_type,
            revenue
        )
    )


print(
    f"Fact rows prepared: "
    f"{len(fact_rows):,}"
)

print(
    f"Unmatched stores: "
    f"{len(unmatched_stores):,}"
)

print(
    f"Unmatched product/date combinations: "
    f"{len(unmatched_products):,}"
)


# -----------------------------
# Stop if stores are missing
# -----------------------------

if unmatched_stores:

    print()
    print("ERROR: Unknown store IDs:")

    for store in sorted(unmatched_stores):
        print(store)

    cur.close()
    pg.close()
    duck.close()

    raise SystemExit(1)


# -----------------------------
# Clear existing fact table
# -----------------------------

print("Clearing existing fact_sales...")

cur.execute(
    "TRUNCATE TABLE fact_sales RESTART IDENTITY"
)


# -----------------------------
# Fast PostgreSQL COPY
# -----------------------------

print("Loading fact_sales using COPY...")

copy_sql = """
COPY fact_sales (
    bill_no,
    line_no,
    business_date,
    store_key,
    product_key,
    quantity,
    unit_price,
    line_type,
    revenue
)
FROM STDIN
WITH (
    FORMAT CSV,
    DELIMITER E'\\t',
    NULL '\\N'
)
"""


# -----------------------------
# Load in chunks
# -----------------------------

chunk_size = 100000

for start in range(
    0,
    len(fact_rows),
    chunk_size
):

    end = min(
        start + chunk_size,
        len(fact_rows)
    )

    chunk = fact_rows[start:end]

    buffer = io.StringIO()

    for row in chunk:

        values = []

        for value in row:

            if value is None:

                values.append("\\N")

            else:

                values.append(
                    str(value)
                    .replace("\t", " ")
                    .replace("\n", " ")
                    .replace("\r", " ")
                )

        buffer.write(
            "\t".join(values)
            + "\n"
        )

    buffer.seek(0)

    cur.copy_expert(
        copy_sql,
        buffer
    )

    print(
        f"Loaded {end:,} / "
        f"{len(fact_rows):,} rows"
    )


pg.commit()


# -----------------------------
# Verification
# -----------------------------

cur.execute("""
SELECT COUNT(*)
FROM fact_sales
""")

fact_count = cur.fetchone()[0]


cur.execute("""
SELECT COUNT(*)
FROM fact_sales
WHERE product_key IS NULL
""")

null_products = cur.fetchone()[0]


cur.execute("""
SELECT
    COUNT(*) AS rows,
    COALESCE(SUM(revenue), 0) AS total_revenue
FROM fact_sales
""")

rows, total_revenue = cur.fetchone()


# -----------------------------
# Line type verification
# -----------------------------

cur.execute("""
SELECT
    line_type,
    COUNT(*) AS rows,
    ROUND(SUM(revenue), 2) AS revenue
FROM fact_sales
GROUP BY line_type
ORDER BY line_type
""")

line_type_results = cur.fetchall()


# -----------------------------
# Final output
# -----------------------------

print()
print("==============================")
print("FACT LOAD COMPLETED")
print("==============================")

print(
    f"Sales rows read:       {len(sales):,}"
)

print(
    f"Fact rows prepared:    {len(fact_rows):,}"
)

print(
    f"Rows in fact_sales:    {fact_count:,}"
)

print(
    f"NULL product keys:     {null_products:,}"
)

print(
    f"Total revenue:         {total_revenue}"
)

print()
print("Revenue by line type:")

for line_type, count, revenue in line_type_results:

    print(
        f"{line_type:10} "
        f"{count:8,} "
        f"{revenue:,.2f}"
    )

print("==============================")


# -----------------------------
# Close connections
# -----------------------------

cur.close()
pg.close()
duck.close()