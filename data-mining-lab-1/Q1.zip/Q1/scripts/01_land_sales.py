import os
import io
import hashlib
import boto3
import pandas as pd

# -----------------------------
# Configuration
# -----------------------------

SALES_DIR = r"..\data\sales"

MINIO_ENDPOINT = "http://localhost:9000"
ACCESS_KEY = "minioadmin"
SECRET_KEY = "minioadmin"

BUCKET = "annapoorna-sales"
PREFIX = "sales"


# -----------------------------
# MinIO connection
# -----------------------------

s3 = boto3.client(
    "s3",
    endpoint_url=MINIO_ENDPOINT,
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name="us-east-1"
)


# -----------------------------
# Identify store and date
# -----------------------------

def parse_filename(filename):
    name = os.path.splitext(os.path.basename(filename))[0]

    parts = name.split("_")

    # SALES_S01_20240101
    store = parts[1]
    business_date = pd.to_datetime(parts[2], format="%Y%m%d")

    return store, business_date


# -----------------------------
# Normalize column names
# -----------------------------

def normalize_columns(df):

    df.columns = [
        str(c).replace("\ufeff", "").strip().lower()
        for c in df.columns
    ]

    column_map = {}

    aliases = {
        "bill_no": ["bill_no", "bill", "bill_number", "billno"],
        "line_no": ["line_no", "line", "line_number", "lineno"],
        "product_code": ["product_code", "item_code", "code", "item"],
        "quantity": ["qty", "quantity"],
        "unit_price": ["unit_price", "price", "rate"],
        "line_type": ["line_type", "type", "kind"],
        "timestamp": ["ts", "txn_time", "timestamp", "transaction_time"]
    }

    for standard_name, possible_names in aliases.items():
        for name in possible_names:
            if name in df.columns:
                column_map[name] = standard_name
                break

    df = df.rename(columns=column_map)

    required = [
        "bill_no",
        "line_no",
        "product_code",
        "quantity",
        "unit_price",
        "line_type"
    ]

    missing = [c for c in required if c not in df.columns]

    if missing:
        raise ValueError(
            "Missing columns: " + ", ".join(missing)
        )

    return df


# -----------------------------
# Read one sales file
# -----------------------------

def read_sales_file(filepath):

    filename = os.path.basename(filepath)

    store, business_date = parse_filename(filename)

    extension = os.path.splitext(filename)[1].lower()

    # Read CSV / Parquet
    if extension == ".parquet":
        df = pd.read_parquet(filepath)

    else:
        # Detect separator
        with open(filepath, "r", encoding="utf-8-sig") as f:
            header = f.readline()

        if ";" in header:
            separator = ";"
        else:
            separator = ","

        df = pd.read_csv(
            filepath,
            sep=separator,
            encoding="utf-8-sig"
        )

    df = normalize_columns(df)

    # Add business information from filename
    df["store_id"] = store
    df["business_date"] = business_date.date()

    # Clean values
    df["bill_no"] = df["bill_no"].astype(str).str.strip()
    df["line_no"] = df["line_no"].astype(str).str.strip()
    df["product_code"] = (
        df["product_code"].astype(str).str.strip()
    )

    df["quantity"] = pd.to_numeric(
        df["quantity"],
        errors="coerce"
    )

    df["unit_price"] = pd.to_numeric(
        df["unit_price"],
        errors="coerce"
    )

    df["line_type"] = (
        df["line_type"]
        .astype(str)
        .str.strip()
        .str.upper()
    )

    return df


# -----------------------------
# Delete previous curated data
# -----------------------------

def delete_existing_data():

    print("Removing previous sales objects...")

    response = s3.list_objects_v2(
        Bucket=BUCKET,
        Prefix=PREFIX + "/"
    )

    objects = response.get("Contents", [])

    while response.get("IsTruncated"):

        response = s3.list_objects_v2(
            Bucket=BUCKET,
            Prefix=PREFIX + "/",
            ContinuationToken=response["NextContinuationToken"]
        )

        objects.extend(response.get("Contents", []))

    if objects:

        delete_list = [
            {"Key": obj["Key"]}
            for obj in objects
        ]

        for i in range(0, len(delete_list), 1000):

            s3.delete_objects(
                Bucket=BUCKET,
                Delete={
                    "Objects": delete_list[i:i + 1000]
                }
            )

        print(f"Deleted {len(delete_list)} previous objects.")

    else:
        print("No previous sales objects found.")


# -----------------------------
# Upload partition
# -----------------------------

def upload_partition(df, store, year, month):

    path = (
        f"{PREFIX}/"
        f"year={year}/"
        f"month={month:02d}/"
        f"store={store}/"
        f"part-000.parquet"
    )

    buffer = io.BytesIO()

    df.to_parquet(
        buffer,
        index=False,
        engine="pyarrow"
    )

    buffer.seek(0)

    s3.put_object(
        Bucket=BUCKET,
        Key=path,
        Body=buffer.getvalue()
    )

    return path


# -----------------------------
# Main loader
# -----------------------------

def main():

    # Find all sales files
    files = []

    for root, dirs, filenames in os.walk(SALES_DIR):

        for filename in filenames:

            if filename.lower().endswith(
                (".csv", ".parquet")
            ):
                files.append(
                    os.path.join(root, filename)
                )

    files.sort()

    print(f"Found {len(files)} sales files")

    if not files:
        print("ERROR: No sales files found.")
        return

    # Start clean
    delete_existing_data()

    # Read all files
    frames = []

    processed = 0

    for i, filepath in enumerate(files, start=1):

        filename = os.path.basename(filepath)

        try:

            df = read_sales_file(filepath)

            frames.append(df)

            processed += 1

            print(
                f"[{i}/{len(files)}] "
                f"{filename} -> {len(df)} rows"
            )

        except Exception as e:

            print(
                f"ERROR: {filename}: {e}"
            )

    if not frames:
        print("No data was loaded.")
        return

    # Combine all source files
    all_sales = pd.concat(
        frames,
        ignore_index=True
    )

    raw_rows = len(all_sales)

    print()
    print(f"Raw rows: {raw_rows:,}")

    # -------------------------
    # Deduplication
    # -------------------------

    before = len(all_sales)

    all_sales = all_sales.drop_duplicates(
        subset=["bill_no", "line_no"],
        keep="first"
    ).copy()

    after = len(all_sales)

    duplicates_removed = before - after

    print(
        f"Duplicate rows removed: "
        f"{duplicates_removed:,}"
    )

    print(
        f"Rows after deduplication: "
        f"{after:,}"
    )

    # -------------------------
    # Sort for deterministic output
    # -------------------------

    all_sales = all_sales.sort_values(
        [
            "store_id",
            "business_date",
            "bill_no",
            "line_no"
        ]
    ).reset_index(drop=True)

    # -------------------------
    # Create partitions
    # -------------------------

    all_sales["year"] = pd.to_datetime(
        all_sales["business_date"]
    ).dt.year

    all_sales["month"] = pd.to_datetime(
        all_sales["business_date"]
    ).dt.month

    partition_count = 0

    for (year, month, store), group in all_sales.groupby(
        ["year", "month", "store_id"],
        sort=True
    ):

        group = group.drop(
            columns=["year", "month"]
        )

        path = upload_partition(
            group,
            store,
            int(year),
            int(month)
        )

        partition_count += 1

        print(
            f"Uploaded partition: {path} "
            f"({len(group):,} rows)"
        )

    # -------------------------
    # Checksum
    # -------------------------

    checksum_source = all_sales[
        [
            "store_id",
            "business_date",
            "bill_no",
            "line_no",
            "product_code",
            "quantity",
            "unit_price",
            "line_type"
        ]
    ].to_csv(
        index=False
    ).encode("utf-8")

    checksum = hashlib.sha256(
        checksum_source
    ).hexdigest()

    print()
    print("==============================")
    print("LOADING COMPLETED")
    print("==============================")
    print(f"Files found:              {len(files):,}")
    print(f"Files processed:          {processed:,}")
    print(f"Raw rows:                 {raw_rows:,}")
    print(f"Rows after deduplication: {after:,}")
    print(f"Duplicates removed:       {duplicates_removed:,}")
    print(f"Partitions created:       {partition_count:,}")
    print(f"SHA256 checksum:          {checksum}")
    print("==============================")


if __name__ == "__main__":
    main()