import duckdb
import psycopg2
import pandas as pd


# -----------------------------
# Connections
# -----------------------------

pg = psycopg2.connect(
    host="localhost",
    port=5432,
    database="annapurna",
    user="annapurna",
    password="annapurna"
)

cur = pg.cursor()

duck = duckdb.connect()

duck.execute("INSTALL httpfs")
duck.execute("LOAD httpfs")

duck.execute("""
CREATE SECRET minio (
    TYPE S3,
    KEY_ID 'minioadmin',
    SECRET 'minioadmin',
    REGION 'us-east-1',
    ENDPOINT 'localhost:9000',
    USE_SSL false,
    URL_STYLE 'path'
);
""")


# -----------------------------
# Read sales
# -----------------------------

print("Reading sales...")

sales = duck.execute("""
SELECT
    store_id,
    business_date,
    bill_no,
    line_no,
    product_code,
    quantity,
    unit_price,
    line_type
FROM read_parquet(
    's3://annapoorna-sales/sales/year=*/month=*/store=*/*.parquet',
    hive_partitioning=true
)
""").fetchdf()

sales["business_date"] = pd.to_datetime(
    sales["business_date"]
).dt.date

sales["product_code"] = (
    sales["product_code"]
    .astype(str)
    .str.strip()
)

sales["unit_price"] = pd.to_numeric(
    sales["unit_price"],
    errors="coerce"
)

print(f"Sales rows: {len(sales):,}")


# -----------------------------
# Read products
# -----------------------------

cur.execute("""
SELECT
    product_sk,
    product_code,
    product_name,
    category_id,
    valid_from,
    valid_to
FROM products
ORDER BY product_code, valid_from
""")

products = pd.DataFrame(
    cur.fetchall(),
    columns=[
        "product_sk",
        "product_code",
        "product_name",
        "category_id",
        "valid_from",
        "valid_to"
    ]
)

products["product_code"] = (
    products["product_code"]
    .astype(str)
    .str.strip()
)


# -----------------------------
# Read price revisions
# -----------------------------

cur.execute("""
SELECT
    product_sk,
    selling_price,
    effective_from,
    effective_to
FROM price_revisions
ORDER BY product_sk, effective_from
""")

prices = pd.DataFrame(
    cur.fetchall(),
    columns=[
        "product_sk",
        "selling_price",
        "effective_from",
        "effective_to"
    ]
)


# -----------------------------
# Match product by code + date
# -----------------------------

print("Matching product versions...")

merged = sales.merge(
    products,
    on="product_code",
    how="left"
)

merged["date_match"] = (
    (merged["business_date"] >= merged["valid_from"]) &
    (merged["business_date"] <= merged["valid_to"])
)


# -----------------------------
# Product match statistics
# -----------------------------

total_rows = len(sales)

matched_product = merged[
    merged["date_match"]
].copy()

matched_product_keys = (
    matched_product[
        ["bill_no", "line_no"]
    ].drop_duplicates()
)

matched_count = len(matched_product_keys)

print()
print("==============================")
print("CORRECTED PRODUCT DIAGNOSTIC")
print("==============================")
print(f"Total sales rows:              {total_rows:,}")
print(f"Date-valid product rows:       {matched_count:,}")
print(
    f"Rows without date-valid product: "
    f"{total_rows - matched_count:,}"
)


# -----------------------------
# Select one product version
# -----------------------------

# There should normally be only one valid product
# version for a given product code and date.

valid_products = merged[
    merged["date_match"]
].copy()

valid_products = valid_products.sort_values(
    [
        "bill_no",
        "line_no",
        "valid_from"
    ]
)

valid_products = valid_products.drop_duplicates(
    subset=["bill_no", "line_no"],
    keep="first"
)


# -----------------------------
# Match applicable price revision
# -----------------------------

valid_products = valid_products.merge(
    prices,
    on="product_sk",
    how="left"
)

valid_products["price_match"] = (
    (valid_products["business_date"] >=
     valid_products["effective_from"]) &
    (valid_products["business_date"] <=
     valid_products["effective_to"])
)

applicable_prices = valid_products[
    valid_products["price_match"]
].copy()


# -----------------------------
# Remove duplicate price rows
# -----------------------------

applicable_prices = (
    applicable_prices
    .sort_values(
        [
            "bill_no",
            "line_no",
            "effective_from"
        ]
    )
    .drop_duplicates(
        subset=["bill_no", "line_no"],
        keep="first"
    )
)


# -----------------------------
# Compare sale price
# -----------------------------

applicable_prices["unit_price_match"] = (
    applicable_prices["unit_price"].round(2)
    ==
    applicable_prices["selling_price"].round(2)
)


price_match_count = (
    applicable_prices[
        "unit_price_match"
    ].sum()
)

price_mismatch_count = (
    len(applicable_prices)
    - price_match_count
)


print()
print(
    f"Rows with applicable price revision: "
    f"{len(applicable_prices):,}"
)

print(
    f"Rows matching applicable selling price: "
    f"{price_match_count:,}"
)

print(
    f"Rows with price mismatch: "
    f"{price_mismatch_count:,}"
)


# -----------------------------
# Product codes with no match
# -----------------------------

no_product = merged[
    ~merged["date_match"]
].copy()

print()
print("Examples of unmatched product/date combinations:")

if len(no_product) > 0:

    examples = (
        no_product[
            [
                "product_code",
                "business_date",
                "unit_price"
            ]
        ]
        .drop_duplicates()
        .head(20)
    )

    print(
        examples.to_string(
            index=False
        )
    )


# -----------------------------
# Reused product codes
# -----------------------------

print()
print("Examples of reused product codes:")

reused = (
    products
    .groupby("product_code")
    .size()
    .reset_index(
        name="versions"
    )
)

reused = reused[
    reused["versions"] > 1
].head(10)

print(
    reused.to_string(
        index=False
    )
)


print()
print("==============================")

cur.close()
pg.close()
duck.close()