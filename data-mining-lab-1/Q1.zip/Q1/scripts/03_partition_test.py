import duckdb

con = duckdb.connect()

con.execute("INSTALL httpfs;")
con.execute("LOAD httpfs;")

con.execute("""
CREATE SECRET minio (
    TYPE S3,
    KEY_ID 'minioadmin',
    SECRET 'minioadmin',
    REGION 'us-east-1',
    ENDPOINT 'localhost:9000',
    USE_SSL false,
    URL_STYLE 'path'
);
""")

query = """
SELECT
    COUNT(*) AS row_count,
    SUM(quantity * unit_price) AS gross_amount
FROM read_parquet(
    's3://annapoorna-sales/sales/year=2024/month=10/store=S03/*.parquet',
    hive_partitioning=true
);
"""

print("Query:")
print(query)

print("Result:")
print(con.execute(query).fetchall())

print()
print("Query plan:")
print(
    con.execute(
        "EXPLAIN " + query
    ).fetchall()[0][1]
)

con.close()