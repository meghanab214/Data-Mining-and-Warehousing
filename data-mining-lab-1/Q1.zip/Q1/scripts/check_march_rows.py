import os
import pandas as pd

SALES_DIR = r"..\data\sales"

def parse_filename(filename):
    name = os.path.splitext(os.path.basename(filename))[0]
    parts = name.split("_")
    return parts[1], pd.to_datetime(parts[2], format="%Y%m%d")

def normalize_columns(df):
    df.columns = [
        str(c).replace("\ufeff", "").strip().lower()
        for c in df.columns
    ]

    aliases = {
        "bill_no": ["bill_no", "bill", "bill_number", "billno"],
        "line_no": ["line_no", "line", "line_number", "lineno"],
    }

    mapping = {}

    for standard, names in aliases.items():
        for name in names:
            if name in df.columns:
                mapping[name] = standard
                break

    return df.rename(columns=mapping)

frames = []

for root, dirs, filenames in os.walk(SALES_DIR):

    for filename in filenames:

        if not filename.lower().endswith((".csv", ".parquet")):
            continue

        try:
            store, business_date = parse_filename(filename)

            if not (
                pd.Timestamp("2024-03-01")
                <= business_date
                <= pd.Timestamp("2024-03-31")
            ):
                continue

            filepath = os.path.join(root, filename)

            if filename.lower().endswith(".parquet"):
                df = pd.read_parquet(filepath)
            else:
                with open(filepath, "r", encoding="utf-8-sig") as f:
                    header = f.readline()

                sep = ";" if ";" in header else ","
                df = pd.read_csv(
                    filepath,
                    sep=sep,
                    encoding="utf-8-sig"
                )

            df = normalize_columns(df)

            df["store_id"] = store
            df["business_date"] = business_date.date()

            frames.append(
                df[
                    [
                        "store_id",
                        "business_date",
                        "bill_no",
                        "line_no"
                    ]
                ]
            )

        except Exception as e:
            print("ERROR:", filename, e)

all_sales = pd.concat(frames, ignore_index=True)

print("Raw March rows:", len(all_sales))

deduped = all_sales.drop_duplicates(
    subset=["bill_no", "line_no"],
    keep="first"
)

print("March rows after dedup:", len(deduped))
print(
    "March duplicates removed:",
    len(all_sales) - len(deduped)
)

print(
    "Unique bill/line keys:",
    all_sales[["bill_no", "line_no"]]
    .drop_duplicates()
    .shape[0]
)