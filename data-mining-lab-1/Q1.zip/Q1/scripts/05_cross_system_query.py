import duckdb

con = duckdb.connect()

# Load DuckDB extensions
con.execute("INSTALL httpfs")
con.execute("LOAD httpfs")

con.execute("INSTALL postgres")
con.execute("LOAD postgres")

# MinIO connection
con.execute("""
CREATE OR REPLACE SECRET minio_secret (
    TYPE S3,
    KEY_ID 'minioadmin',
    SECRET 'minioadmin',
    REGION 'us-east-1',
    ENDPOINT 'localhost:9000',
    URL_STYLE 'path',
    USE_SSL false
)
""")

# Connect DuckDB directly to PostgreSQL
con.execute("""
ATTACH 'host=localhost port=5432 dbname=annapurna user=annapurna password=annapurna'
AS pg (TYPE POSTGRES, READ_ONLY)
""")

# Cross-system query
query = """
SELECT
    s.store_id,
    c.category_name,
    SUM(
        CASE
            WHEN s.line_type = 'SALE'
                THEN s.quantity * s.unit_price
            WHEN s.line_type IN ('RETURN', 'DISCOUNT')
                THEN -ABS(s.quantity * s.unit_price)
            ELSE 0
        END
    ) AS revenue
FROM read_parquet(
    's3://annapoorna-sales/sales/year=2024/month=10/store=S03/*.parquet',
    hive_partitioning=true
) s
JOIN pg.public.products p
    ON s.product_code = p.product_code
    AND s.business_date BETWEEN p.valid_from AND p.valid_to
JOIN pg.public.product_categories c
    ON p.category_id = c.category_id
WHERE s.line_type IN ('SALE', 'RETURN', 'DISCOUNT')
GROUP BY s.store_id, c.category_name
ORDER BY s.store_id, c.category_name
"""

print("Cross-system query result:")
print(con.execute(query).fetchdf())

print("\nQuery execution plan:")
plan = con.execute("EXPLAIN ANALYZE " + query).fetchall()

for row in plan:
    print(row[1])

con.close()