TASK-A


TASK-B
Q1(b) - Idempotency Test

Run 1
Rows after deduplication: 1,120,924
SHA256 checksum: 774bc94f13ebb6ffd1793688a19527c96c6f057c1d57ad9925cfff1a10a38df6

Run 2
Rows after deduplication: 1,120,924
SHA256 checksum: 774bc94f13ebb6ffd1793688a19527c96c6f057c1d57ad9925cfff1a10a38df6

Run 3
Rows after deduplication: 1,120,924
SHA256 checksum: 774bc94f13ebb6ffd1793688a19527c96c6f057c1d57ad9925cfff1a10a38df6

Result:
All three runs produced the same deduplicated row count
and the same SHA256 checksum.

Therefore, the loader is idempotent.


TASK-C
Products in master:                 1,224
Reused product codes:               confirmed
Date-valid product rows:            766,796
Fact rows:                        1,120,924

TASK-E
DuckDB was used as the analytical query engine to join sales data stored as Parquet files in MinIO with master data stored in PostgreSQL. The sales data was accessed using READ_PARQUET, while PostgreSQL tables were accessed using POSTGRES_SCAN. No sales or master data was copied into another database. The EXPLAIN ANALYZE output provides engine-level evidence that the query accessed both systems directly.

TASK-F
| Month | Pipeline Revenue (₹) | Finance Revenue (₹) | Difference (₹) | Classification              |
| ----- | -------------------: | ------------------: | -------------: | --------------------------- |
| Jan   |        38,446,071.33 |       38,446,071.33 |           0.00 | Match                       |
| Feb   |        34,887,085.55 |       34,887,085.55 |           0.00 | Match                       |
| Mar   |        41,971,649.09 |       42,457,899.09 |    +486,250.00 | Revenue scope difference    |
| Apr   |        37,958,457.37 |       37,958,457.37 |           0.00 | Match                       |
| May   |        41,764,716.40 |       41,764,716.40 |           0.00 | Match                       |
| Jun   |        38,987,082.82 |       38,987,082.82 |           0.00 | Match                       |
| Jul   |        40,295,160.11 |       40,527,291.81 |    +232,131.70 | Source data issue           |
| Aug   |        45,252,181.75 |       45,252,181.75 |           0.00 | Match                       |
| Sep   |        44,615,037.46 |       44,615,037.46 |           0.00 | Match                       |
| Oct   |        56,359,195.92 |       56,359,195.92 |           0.00 | Match                       |
| Nov   |        51,583,838.47 |       51,583,838.47 |           0.00 | Match                       |
| Dec   |        50,745,259.48 |       50,745,209.00 |         -50.48 | Revenue definition/rounding |


Investigation of differences
March 2024: Difference of ₹486,250 is because finance includes an institutional order invoiced outside the till. This amount is not present in the supplied sales files. Therefore, this is a scope/revenue-definition difference, not a pipeline bug.
July 2024: Difference of ₹232,131.70 is because sales exports for S07 on July 9, 10 and 11 are missing from the supplied folder. This is a source data issue.
December 2024: Difference of ₹50.48 is due to rounding. Finance rounds each bill to the nearest rupee before summing, whereas the pipeline aggregates the line-level amounts.
Conclusion

The pipeline matches finance for 9 of the 12 months. The three differences are explained by an external institutional invoice in March, missing S07 source files in July, and bill-level rounding in December. These should be taken back to finance as reconciliation items. No pipeline bug was identified in the three differences.